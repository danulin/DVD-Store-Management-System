<?php
// FIXED - NO HARDCODE - Auto detects folder name (store, online_business_website, etc)
session_start();

// Auto-detect protocol
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';

// Get current script directory and clean it

$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
$scriptDir = preg_replace('#/(admin|config|includes)$#', '', $scriptDir);
$scriptDir = rtrim($scriptDir, '/');


define('BASE_URL', $protocol . $host . $scriptDir);
define('SITE_NAME', 'TechMart - Online Store');
define('ADMIN_EMAIL', 'admin@techmart.lk');

// Auto loader for DB
require_once __DIR__ . '/database.php';
$database = new Database();
$db = $database->getConnection();

require_once __DIR__ . '/../includes/functions.php';
?>
