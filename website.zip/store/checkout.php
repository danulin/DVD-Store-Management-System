<?php
require_once 'config/config.php';
requireLogin();
$pageTitle = "Checkout";
include 'includes/header.php';

$cart = $_SESSION['cart'] ?? [];
if(empty($cart)){ header("Location: cart.php"); exit; }

$total = 0;
foreach($cart as $item){ $total += $item['price'] * $item['quantity']; }

$userStmt = $db->prepare("SELECT * FROM users WHERE id=:id");
$userStmt->execute([':id'=>$_SESSION['user_id']]);
$user = $userStmt->fetch();

$success = false;
if($_SERVER['REQUEST_METHOD']=='POST'){
    $name = sanitize($_POST['name']);
    $address = sanitize($_POST['address']);
    $phone = sanitize($_POST['phone']);
    
    try{
        $db->beginTransaction();
        // INSERT order (DML)
        $stmt = $db->prepare("INSERT INTO orders (user_id, total_amount, shipping_name, shipping_address, shipping_phone, status) VALUES (:uid, :total, :name, :addr, :phone, 'pending')");
        $stmt->execute([':uid'=>$_SESSION['user_id'], ':total'=>$total, ':name'=>$name, ':addr'=>$address, ':phone'=>$phone]);
        $orderId = $db->lastInsertId();
        
        // INSERT order_items + UPDATE stock
        foreach($cart as $item){
            $stmt = $db->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (:oid, :pid, :qty, :price)");
            $stmt->execute([':oid'=>$orderId, ':pid'=>$item['id'], ':qty'=>$item['quantity'], ':price'=>$item['price']]);
            
            $stmt = $db->prepare("UPDATE products SET stock_quantity = stock_quantity - :qty WHERE id=:id");
            $stmt->execute([':qty'=>$item['quantity'], ':id'=>$item['id']]);
        }
        $db->commit();
        $_SESSION['cart']=[];
        $success = true;
    } catch(Exception $e){
        $db->rollBack();
        $error = $e->getMessage();
    }
}
?>
<div class="container py-5">
  <?php if($success): ?>
    <div class="text-center py-5">
      <i class="bi bi-check-circle-fill text-success" style="font-size:5rem"></i>
      <h2 class="mt-3">Order Placed Successfully!</h2>
      <p>Your order ID is #<?= $orderId ?>. We will contact you soon.</p>
      <a href="account.php" class="btn btn-primary">View My Orders</a>
      <a href="shop.php" class="btn btn-outline-secondary ms-2">Continue Shopping</a>
    </div>
  <?php else: ?>
  <h3 class="fw-bold mb-4">Checkout</h3>
  <?php if(isset($error)): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
  <div class="row">
    <div class="col-md-7">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5>Shipping Details</h5>
          <form method="POST">
            <div class="mb-3"><label class="form-label">Full Name</label><input type="text" name="name" class="form-control" required value="<?= sanitize($user['name']) ?>"></div>
            <div class="mb-3"><label class="form-label">Address</label><textarea name="address" class="form-control" required rows="3"></textarea></div>
            <div class="mb-3"><label class="form-label">Phone</label><input type="text" name="phone" class="form-control" required></div>
            <div class="mb-3"><label class="form-label">Email</label><input type="email" class="form-control" value="<?= sanitize($user['email']) ?>" readonly></div>
            <button type="submit" class="btn btn-primary w-100 btn-lg">Place Order - <?= formatPrice($total) ?></button>
          </form>
        </div>
      </div>
    </div>
    <div class="col-md-5">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5>Order Summary (<?= count($cart) ?> items)</h5>
          <?php foreach($cart as $item): ?>
            <div class="d-flex justify-content-between small py-2 border-bottom"><span><?= sanitize($item['name']) ?> x <?= $item['quantity'] ?></span><span><?= formatPrice($item['price']*$item['quantity']) ?></span></div>
          <?php endforeach; ?>
          <div class="d-flex justify-content-between fw-bold mt-3 fs-5"><span>Total</span><span><?= formatPrice($total) ?></span></div>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>
