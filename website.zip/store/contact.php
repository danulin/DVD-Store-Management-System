<?php
require_once 'config/config.php';
$pageTitle="Contact Us";
$success=''; $error='';
if($_SERVER['REQUEST_METHOD']=='POST'){
    $name = sanitize($_POST['name']);
    $email = trim($_POST['email']);
    $subject = sanitize($_POST['subject']);
    $message = sanitize($_POST['message']);
    if(empty($name) || empty($email) || empty($message)){
        $error="All fields required!";
    } else {
        $stmt = $db->prepare("INSERT INTO contact_messages (name, email, subject, message) VALUES (:name, :email, :subject, :message)");
        if($stmt->execute([':name'=>$name, ':email'=>$email, ':subject'=>$subject, ':message'=>$message])){
            $success="Thank you! Your message has been sent. We will get back to you soon.";
        } else {
            $error="Failed to send message.";
        }
    }
}
include 'includes/header.php';
?>
<style>
.contact-card { background:white; border:1px solid #f1f5f9; border-radius:20px; }
.contact-info-item { display:flex; gap:14px; padding:16px; border-radius:14px; transition:all 0.2s; }
.contact-info-item:hover { background:#f8fafc; }
.contact-icon { width:44px; height:44px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:18px; flex-shrink:0; }
</style>
<div class="container py-5">
  <div class="text-center mb-5">
    <h1 class="fw-bold" style="font-family:'Plus Jakarta Sans'; font-size:36px;">Contact Us</h1>
    <p class="text-muted">Have questions? We'd love to hear from you. Send us a message.</p>
  </div>
  <div class="row g-4">
    <div class="col-lg-4">
      <div class="contact-card p-4 h-100">
        <h5 class="fw-bold mb-4" style="font-family:'Plus Jakarta Sans';">Get in Touch</h5>
        <div class="contact-info-item">
          <div class="contact-icon" style="background:#eef2ff; color:#6366f1;"><i class="bi bi-geo-alt"></i></div>
          <div><div class="fw-semibold small">Our Location</div><div class="text-muted small">Colombo, Sri Lanka<br>Island-wide delivery</div></div>
        </div>
        <div class="contact-info-item">
          <div class="contact-icon" style="background:#ecfdf5; color:#10b981;"><i class="bi bi-telephone"></i></div>
          <div><div class="fw-semibold small">Phone Number</div><div class="text-muted small">+94 11 234 5678<br>+94 77 123 4567</div></div>
        </div>
        <div class="contact-info-item">
          <div class="contact-icon" style="background:#fffbeb; color:#f59e0b;"><i class="bi bi-envelope"></i></div>
          <div><div class="fw-semibold small">Email Address</div><div class="text-muted small">support@techmart.lk<br>sales@techmart.lk</div></div>
        </div>
        <div class="contact-info-item">
          <div class="contact-icon" style="background:#fef2f2; color:#ef4444;"><i class="bi bi-clock"></i></div>
          <div><div class="fw-semibold small">Working Hours</div><div class="text-muted small">Mon - Sat: 9AM - 6PM<br>Sunday: Closed</div></div>
        </div>
        <hr class="my-4" style="border-color:#f1f5f9;">
        <h6 class="fw-bold small text-uppercase" style="letter-spacing:0.06em;">Follow Us</h6>
        <div class="d-flex gap-2 mt-2">
          <a href="#" class="btn btn-sm" style="width:36px; height:36px; border-radius:10px; background:#f1f5f9; display:flex; align-items:center; justify-content:center;"><i class="bi bi-facebook"></i></a>
          <a href="#" class="btn btn-sm" style="width:36px; height:36px; border-radius:10px; background:#f1f5f9; display:flex; align-items:center; justify-content:center;"><i class="bi bi-instagram"></i></a>
          <a href="#" class="btn btn-sm" style="width:36px; height:36px; border-radius:10px; background:#f1f5f9; display:flex; align-items:center; justify-content:center;"><i class="bi bi-tiktok"></i></a>
        </div>
      </div>
    </div>
    <div class="col-lg-8">
      <div class="contact-card p-4 p-md-5">
        <?php if($success): ?><div class="alert alert-success" style="border-radius:12px;"><?= $success ?></div><?php endif; ?>
        <?php if($error): ?><div class="alert alert-danger" style="border-radius:12px;"><?= $error ?></div><?php endif; ?>
        <form method="POST">
          <div class="row g-3">
            <div class="col-md-6"><label class="form-label small fw-semibold">Your Name</label><input type="text" name="name" class="form-control" style="border-radius:12px; padding:12px 16px;" placeholder="John Doe" required></div>
            <div class="col-md-6"><label class="form-label small fw-semibold">Email Address</label><input type="email" name="email" class="form-control" style="border-radius:12px; padding:12px 16px;" placeholder="john@example.com" required></div>
            <div class="col-12"><label class="form-label small fw-semibold">Subject</label><input type="text" name="subject" class="form-control" style="border-radius:12px; padding:12px 16px;" placeholder="How can we help you?"></div>
            <div class="col-12"><label class="form-label small fw-semibold">Message</label><textarea name="message" rows="5" class="form-control" style="border-radius:12px; padding:12px 16px;" placeholder="Tell us more..." required></textarea></div>
            <div class="col-12"><button class="btn btn-dark w-100" style="border-radius:12px; padding:12px; font-weight:600;">Send Message <i class="bi bi-send ms-1"></i></button></div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
