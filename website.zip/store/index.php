<?php
require_once 'config/config.php';
$pageTitle = "Home";
include 'includes/header.php';

$cats = $db->query("SELECT * FROM categories ORDER BY id LIMIT 6")->fetchAll();
$products = $db->query("SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.status='active' ORDER BY p.created_at DESC LIMIT 8")->fetchAll();
?>
<style>
.hero-premium { background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%); color:white; padding:90px 0 80px; position:relative; overflow:hidden; }
.hero-premium::before { content:''; position:absolute; width:800px; height:800px; background:radial-gradient(circle, rgba(99,102,241,0.25) 0%, transparent 70%); top:-300px; right:-200px; }
.hero-title { font-family:'Plus Jakarta Sans'; font-weight:800; font-size:48px; line-height:1.05; letter-spacing:-0.03em; }
.product-card { border:1px solid #f1f5f9; border-radius:20px; overflow:hidden; transition:all 0.3s; background:white; }
.product-card:hover { transform:translateY(-6px); box-shadow:0 20px 40px rgba(15,23,42,0.1); border-color:transparent; }
.product-img { height:200px; object-fit:cover; background:#f8fafc; transition:transform 0.4s; }
.product-card:hover .product-img { transform:scale(1.05); }
.cat-card { border:1px solid #f1f5f9; border-radius:16px; padding:20px; text-align:center; transition:all 0.3s; background:white; }
.cat-card:hover { background:#0f172a; color:white; transform:translateY(-3px); }
</style>

<section class="hero-premium">
  <div class="container position-relative">
    <div class="row align-items-center">
      <div class="col-lg-6">
        <span class="badge mb-3" style="background:rgba(99,102,241,0.15); border:1px solid rgba(99,102,241,0.3); color:#a5b4fc; padding:8px 14px; border-radius:100px; font-size:12px;"><i class="bi bi-lightning me-1"></i> NEW ARRIVALS - UP TO 30% OFF</span>
        <h1 class="hero-title">Best Deals on<br>Electronics & Gadgets</h1>
        <p class="mt-3" style="color:#cbd5e1; font-size:17px; max-width:480px;">Shop smartphones, laptops, accessories and more. Island-wide delivery, 1-year warranty, 24/7 support.</p>
        <div class="d-flex gap-3 mt-4">
          <a href="<?= BASE_URL ?>/shop.php" class="btn btn-light btn-lg px-4" style="border-radius:100px; font-weight:700;">Shop Now <i class="bi bi-arrow-right ms-1"></i></a>
          <a href="<?= BASE_URL ?>/about.php" class="btn btn-lg px-4" style="border-radius:100px; background:rgba(255,255,255,0.1); border:1px solid rgba(255,255,255,0.15); color:white; font-weight:600;">Learn More</a>
        </div>
        <div class="d-flex gap-4 mt-5">
          <div class="d-flex align-items-center gap-2"><i class="bi bi-truck fs-5" style="color:#a5b4fc;"></i><small style="color:#94a3b8;">Free delivery over Rs.5000</small></div>
          <div class="d-flex align-items-center gap-2"><i class="bi bi-shield-check fs-5" style="color:#6ee7b7;"></i><small style="color:#94a3b8;">1 year warranty</small></div>
        </div>
      </div>
      <div class="col-lg-6 d-none d-lg-block">
        <div class="position-relative" style="height:420px;">
          <div style="position:absolute; top:20px; right:40px; background:white; border-radius:20px; padding:16px; width:220px; box-shadow:0 20px 60px rgba(0,0,0,0.3); transform:rotate(3deg);">
            <img src="<?= BASE_URL ?>/assets/images/products/product_001_iphone-15-pro-max-256gb_techmart.jpg" style="width:100%; height:140px; object-fit:cover; border-radius:12px; background:#f8fafc;">
            <div class="fw-bold mt-2" style="color:#0f172a; font-size:13px;">iPhone 15 Pro Max</div><div class="small text-muted">Rs.450,000</div>
          </div>
          <div style="position:absolute; bottom:40px; left:20px; background:white; border-radius:20px; padding:16px; width:200px; box-shadow:0 20px 60px rgba(0,0,0,0.3); transform:rotate(-2deg);">
            <img src="<?= BASE_URL ?>/assets/images/products/product_003_macbook-air-m2-13-inch_techmart.jpg" style="width:100%; height:120px; object-fit:cover; border-radius:12px; background:#f8fafc;">
            <div class="fw-bold mt-2" style="color:#0f172a; font-size:13px;">MacBook Air M2</div><div class="small text-muted">Rs.320,000</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="py-5" style="background:#f8fafc;">
  <div class="container">
    <div class="d-flex justify-content-between align-items-end mb-4">
      <div><h3 class="fw-bold mb-1" style="font-family:'Plus Jakarta Sans';">Shop by Category</h3><p class="text-muted small mb-0">Find what you need faster</p></div>
      <a href="<?= BASE_URL ?>/shop.php" class="text-decoration-none small fw-semibold" style="color:#6366f1;">View all <i class="bi bi-arrow-right"></i></a>
    </div>
    <div class="row g-3">
      <?php foreach($cats as $cat): ?>
      <div class="col-6 col-md-4 col-lg-2">
        <a href="<?= BASE_URL ?>/shop.php?category=<?= $cat['id'] ?>" class="text-decoration-none">
          <div class="cat-card h-100">
            <div class="fs-3 mb-2"><i class="bi bi-tags"></i></div>
            <h6 class="mb-0 small fw-bold"><?= htmlspecialchars($cat['name']) ?></h6>
          </div>
        </a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="py-5 bg-white">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div><h3 class="fw-bold mb-1" style="font-family:'Plus Jakarta Sans';">Featured Products</h3><p class="text-muted small mb-0">Handpicked for you</p></div>
      <a href="<?= BASE_URL ?>/shop.php" class="btn btn-sm" style="background:#f8fafc; border:1px solid #f1f5f9; border-radius:100px; font-weight:600;">View All</a>
    </div>
    <div class="row g-4">
      <?php foreach($products as $p): 
        // FIX: Use local path, ensure BASE_URL prefix
        $img = $p['image_url'];
        if(strpos($img, 'http')===0 && strpos($img, 'assets/')===false){
            // Old external URL - fallback to local based on slug
            $img = BASE_URL . '/assets/images/products/' . $p['slug'] . '.jpg';
            // If file doesn't exist, use placeholder logic - for now use BASE_URL + original local path if exists
            $img = BASE_URL . '/' . $p['image_url'];
            if(strpos($p['image_url'], 'assets/')===false){
                $img = BASE_URL . '/assets/images/products/product_001_iphone-15-pro-max-256gb_techmart.jpg';
            }
        } else {
            if(strpos($img, 'http')!==0){
                $img = BASE_URL . '/' . ltrim($img, '/');
            }
        }
        // Correct final path - use BASE_URL + image_url if image_url already local
        $finalImg = (strpos($p['image_url'], 'assets/')===0) ? BASE_URL . '/' . $p['image_url'] : $p['image_url'];
        // If still external, use first product as fallback
        if(strpos($finalImg, 'unsplash.com')!==false){
            $finalImg = BASE_URL . '/assets/images/products/product_001_iphone-15-pro-max-256gb_techmart.jpg';
        }
      ?>
      <div class="col-6 col-md-3">
        <div class="product-card h-100">
          <div style="overflow:hidden; background:#f8fafc;"><img src="<?= $finalImg ?>" class="product-img w-100" alt="<?= htmlspecialchars($p['name']) ?>" onerror="this.src='<?= BASE_URL ?>/assets/images/products/product_001_iphone-15-pro-max-256gb_techmart.jpg'"></div>
          <div class="p-3">
            <small class="text-muted" style="font-size:11px; letter-spacing:0.06em; text-transform:uppercase;"><?= htmlspecialchars($p['cat_name']) ?></small>
            <div class="fw-semibold mt-1" style="font-size:14px; line-height:1.3; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; min-height:36px;"><?= htmlspecialchars($p['name']) ?></div>
            <div class="d-flex justify-content-between align-items-center mt-2">
              <span class="fw-bold" style="font-family:'Plus Jakarta Sans';">Rs.<?= number_format($p['price'],0) ?></span>
              <span class="badge" style="background:#f1f5f9; color:#64748b; font-size:10px;">In Stock</span>
            </div>
            <a href="<?= BASE_URL ?>/product.php?id=<?= $p['id'] ?>" class="btn btn-dark w-100 mt-3 btn-sm" style="border-radius:10px; font-weight:600;">View Details</a>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php include 'includes/footer.php'; ?>
