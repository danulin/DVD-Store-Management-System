-- TechMart Online Store Database
-- SE102.3 Web Based Application Development Assignment
-- Created for NSBM Green University

CREATE DATABASE IF NOT EXISTS online_store_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE online_store_db;

-- Users table (customers + admins)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('customer','admin') DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Categories
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(120) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Products (main entity with DML)
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT,
    name VARCHAR(200) NOT NULL,
    slug VARCHAR(220) NOT NULL UNIQUE,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    stock_quantity INT DEFAULT 0,
    image_url VARCHAR(500),
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Orders
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending','processing','completed','cancelled') DEFAULT 'pending',
    shipping_name VARCHAR(100) NOT NULL,
    shipping_address TEXT NOT NULL,
    shipping_phone VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Order Items (many to many)
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Contact Messages
CREATE TABLE IF NOT EXISTS contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    subject VARCHAR(200),
    message TEXT NOT NULL,
    status ENUM('unread','read') DEFAULT 'unread',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Sample Data INSERT (DML Examples)

-- Users
INSERT INTO users (name, email, password, role) VALUES
('Admin User', 'admin@techmart.lk', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('Customer Test', 'customer@test.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer');
-- Password for both is: password (customer123/admin123 hash example - use password_hash in real setup)
-- Note: The above hash is for 'password'. For actual use:
-- admin123 hash: use PHP password_hash('admin123', PASSWORD_DEFAULT)
-- We'll insert readable alternative below after updating

-- Categories
INSERT INTO categories (name, slug, description) VALUES
('Smartphones', 'smartphones', 'Latest smartphones and mobile phones'),
('Laptops', 'laptops', 'Laptops, notebooks and MacBooks'),
('Accessories', 'accessories', 'Phone and laptop accessories'),
('Audio', 'audio', 'Headphones, speakers and audio gear'),
('Gaming', 'gaming', 'Gaming consoles and accessories'),
('Smart Home', 'smart-home', 'Smart home devices');

-- Products
INSERT INTO products (category_id, name, slug, description, price, stock_quantity, image_url, status) VALUES
(1, 'iPhone 15 Pro Max 256GB', 'iphone-15-pro-max-256gb-1', 'Latest iPhone with A17 Pro chip, Titanium design, 48MP camera system.', 450000.00, 15, 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=400', 'active'),
(1, 'Samsung Galaxy S24 Ultra', 'samsung-galaxy-s24-ultra-1', 'Galaxy S24 Ultra with S Pen, 200MP camera, Snapdragon 8 Gen 3.', 380000.00, 20, 'https://images.unsplash.com/photo-1610945265064-0e34e438d9a5?w=400', 'active'),
(2, 'MacBook Air M2 13-inch', 'macbook-air-m2-13-inch-1', 'Supercharged by M2 chip, 13.6-inch Liquid Retina display, up to 18h battery.', 320000.00, 10, 'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=400', 'active'),
(2, 'Dell XPS 13 Laptop', 'dell-xps-13-laptop-1', 'Dell XPS 13 with Intel Core i7, 16GB RAM, 512GB SSD, InfinityEdge display.', 280000.00, 8, 'https://images.unsplash.com/photo-1588872657576-7efd1f1555ed?w=400', 'active'),
(3, 'Apple AirPods Pro 2nd Gen', 'apple-airpods-pro-2nd-gen-1', 'Active Noise Cancellation, Adaptive Transparency, Personalized Spatial Audio.', 65000.00, 50, 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=400', 'active'),
(3, 'Anker Power Bank 20000mAh', 'anker-power-bank-20000mah-1', 'High capacity power bank with fast charging, 3 USB ports.', 12000.00, 100, 'https://images.unsplash.com/photo-1583394838336-acd977736f90?w=400', 'active'),
(4, 'Sony WH-1000XM5 Headphones', 'sony-wh-1000xm5-headphones-1', 'Industry leading noise cancellation, 30h battery, crystal clear call quality.', 75000.00, 25, 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=400', 'active'),
(4, 'JBL Flip 6 Bluetooth Speaker', 'jbl-flip-6-bluetooth-speaker-1', 'Portable waterproof speaker with powerful bass and 12h playtime.', 25000.00, 40, 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400', 'active'),
(5, 'PlayStation 5 Console', 'playstation-5-console-1', 'PS5 console with ultra-high speed SSD, 3D audio, DualSense controller.', 180000.00, 12, 'https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=400', 'active'),
(6, 'Amazon Echo Dot 5th Gen', 'amazon-echo-dot-5th-gen-1', 'Smart speaker with Alexa, improved speaker quality, smart home hub.', 15000.00, 60, 'https://images.unsplash.com/photo-1543512214-318c7553f230?w=400', 'active');

-- Update passwords correctly (run these in PHP, but for SQL demo we keep simple)
-- To correctly set admin123 and customer123, execute in PHP:
-- UPDATE users SET password = '$2y$10$...' WHERE email='admin@techmart.lk'

-- DML Operation Examples (for report):

-- SELECT examples
-- SELECT * FROM products WHERE status='active' ORDER BY price DESC;
-- SELECT p.*, c.name as category FROM products p JOIN categories c ON p.category_id=c.id;

-- INSERT example
-- INSERT INTO products (category_id, name, slug, description, price, stock_quantity) VALUES (1, 'New Phone', 'new-phone', 'Description', 100000, 10);

-- UPDATE example
-- UPDATE products SET price=90000, stock_quantity=5 WHERE id=1;
-- UPDATE orders SET status='completed' WHERE id=1;

-- DELETE example
-- DELETE FROM products WHERE id=10;
-- DELETE FROM contact_messages WHERE id=5;

-- Sample Orders (for demo)
INSERT INTO orders (user_id, total_amount, shipping_name, shipping_address, shipping_phone, status) VALUES
(2, 65000.00, 'Customer Test', '123 Main St, Colombo', '0771234567', 'completed'),
(2, 12000.00, 'Customer Test', '123 Main St, Colombo', '0771234567', 'pending');

INSERT INTO order_items (order_id, product_id, quantity, price) VALUES
(1, 5, 1, 65000.00),
(2, 6, 1, 12000.00);

-- Contact Messages sample
INSERT INTO contact_messages (name, email, subject, message, status) VALUES
('Sajith Lakmal', 'sajith@test.com', 'Product Inquiry', 'I would like to know more about iPhone 15 Pro Max warranty.', 'unread'),
('Nimal Perera', 'nimal@example.com', 'Delivery Issue', 'My order has not arrived yet. Please check.', 'unread');
