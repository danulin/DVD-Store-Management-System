<?php
require_once 'config/config.php';
if(isLoggedIn()){
    if(isAdmin()){ header("Location: admin/index.php"); exit; }
    else { header("Location: index.php"); exit; }
}
$error='';
if($_SERVER['REQUEST_METHOD']=='POST'){
    $email = trim($_POST['email']);
    $pass = $_POST['password'];
    $stmt = $db->prepare("SELECT * FROM users WHERE email=:email LIMIT 1");
    $stmt->execute([':email'=>$email]);
    $user = $stmt->fetch();
    if($user && password_verify($pass, $user['password'])){
        $_SESSION['user_id']=$user['id'];
        $_SESSION['user_name']=$user['name'];
        $_SESSION['role']=$user['role'];
        $_SESSION['email']=$user['email'];
        if($user['role']=='admin') header("Location: admin/index.php");
        else header("Location: index.php");
        exit;
    } else {
        $error = "Invalid email or password! Try 'password' if you didn't run reset_admin.php";
    }
}
$pageTitle="Login";
include 'includes/header.php';
?>
<style>
.login-card { background:white; border:1px solid #f1f5f9; border-radius:24px; overflow:hidden; box-shadow:0 20px 60px rgba(15,23,42,0.08); }
</style>
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-5">
      <div class="login-card">
        <div class="p-4 p-md-5">
          <div class="text-center mb-4">
            <img src="<?= BASE_URL ?>/assets/images/logo.png" style="height:36px;" alt="TechMart">
            <h4 class="fw-bold mt-3 mb-1" style="font-family:'Plus Jakarta Sans';">Welcome back</h4>
            <p class="text-muted small">Login to your TechMart account</p>
          </div>
          <?php if($error): ?><div class="alert alert-danger" style="border-radius:12px; font-size:13px;"><?= $error ?></div><?php endif; ?>
          <form method="POST">
            <div class="mb-3"><label class="form-label small fw-semibold">Email Address</label><input type="email" name="email" class="form-control" style="border-radius:12px; padding:12px 16px;" placeholder="user@gmail.lk" value="<?= htmlspecialchars($_POST['email'] ?? 'admin@techmart.lk') ?>" required></div>
            <div class="mb-4"><label class="form-label small fw-semibold">Password</label><input type="password" name="password" class="form-control" style="border-radius:12px; padding:12px 16px;" placeholder="••••••••" required></div>
            <button class="btn btn-dark w-100" style="border-radius:12px; padding:12px; font-weight:600;">Login <i class="bi bi-arrow-right ms-1"></i></button>
          </form>
          <p class="text-center mt-4 small">Don't have account? <a href="<?= BASE_URL ?>/register.php" style="color:#6366f1; font-weight:600;">Register here</a></p>
          <div class="mt-4 p-3" style="background:#f8fafc; border:1px solid #f1f5f9; border-radius:12px;">
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
