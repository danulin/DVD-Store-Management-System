<?php
require_once 'config/config.php';
if(isLoggedIn()){ header("Location: index.php"); exit; }
$error=''; $success='';
if($_SERVER['REQUEST_METHOD']=='POST'){
    $name = sanitize($_POST['name']);
    $email = trim($_POST['email']);
    $pass = $_POST['password'];
    $cpass = $_POST['cpassword'];
    if($pass !== $cpass){
        $error="Passwords do not match!";
    } else {
        $check = $db->prepare("SELECT id FROM users WHERE email=:email");
        $check->execute([':email'=>$email]);
        if($check->fetch()){
            $error="Email already exists!";
        } else {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $stmt = $db->prepare("INSERT INTO users (name, email, password, role) VALUES (:name, :email, :pass, 'customer')");
            if($stmt->execute([':name'=>$name, ':email'=>$email, ':pass'=>$hash])){
                $success="Account created! Please login.";
            }
        }
    }
}
$pageTitle="Register";
include 'includes/header.php';
?>
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-5">
      <div class="card shadow">
        <div class="card-body p-4">
          <h4 class="fw-bold text-center mb-4">Create Account</h4>
          <?php if($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
          <?php if($success): ?><div class="alert alert-success"><?= $success ?> <a href="login.php">Login</a></div><?php endif; ?>
          <form method="POST">
            <div class="mb-3"><label>Full Name</label><input type="text" name="name" class="form-control" required></div>
            <div class="mb-3"><label>Email</label><input type="email" name="email" class="form-control" required></div>
            <div class="mb-3"><label>Password</label><input type="password" name="password" class="form-control" required minlength="6"></div>
            <div class="mb-3"><label>Confirm Password</label><input type="password" name="cpassword" class="form-control" required></div>
            <button class="btn btn-primary w-100">Register</button>
          </form>
          <p class="text-center mt-3 small">Already have account? <a href="login.php">Login here</a></p>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
