<?php
require_once '../config/config.php';
requireAdmin();
require_once '../includes/admin_header.php';

$totalProducts = $db->query("SELECT COUNT(*) FROM products")->fetchColumn();
$totalCategories = $db->query("SELECT COUNT(*) FROM categories")->fetchColumn();
$totalOrders = $db->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$totalUsers = $db->query("SELECT COUNT(*) FROM users WHERE role='customer'")->fetchColumn();
$totalRevenue = $db->query("SELECT SUM(total_amount) FROM orders WHERE status='completed'")->fetchColumn();
$pendingOrders = $db->query("SELECT COUNT(*) FROM orders WHERE status='pending'")->fetchColumn();

$recentOrders = $db->query("SELECT o.*, u.name as user_name FROM orders o JOIN users u ON o.user_id=u.id ORDER BY o.created_at DESC LIMIT 5")->fetchAll();
?>
<h3 class="fw-bold mb-4">Dashboard</h3>
<div class="row g-3 mb-4">
  <div class="col-md-2"><div class="card bg-primary text-white"><div class="card-body"><h6>Products</h6><h3><?= $totalProducts ?></h3></div></div></div>
  <div class="col-md-2"><div class="card bg-success text-white"><div class="card-body"><h6>Categories</h6><h3><?= $totalCategories ?></h3></div></div></div>
  <div class="col-md-2"><div class="card bg-warning text-dark"><div class="card-body"><h6>Orders</h6><h3><?= $totalOrders ?></h3></div></div></div>
  <div class="col-md-2"><div class="card bg-info text-white"><div class="card-body"><h6>Customers</h6><h3><?= $totalUsers ?></h3></div></div></div>
  <div class="col-md-2"><div class="card bg-dark text-white"><div class="card-body"><h6>Revenue</h6><h3>Rs.<?= number_format($totalRevenue?:0,0) ?></h3></div></div></div>
  <div class="col-md-2"><div class="card bg-danger text-white"><div class="card-body"><h6>Pending</h6><h3><?= $pendingOrders ?></h3></div></div></div>
</div>

<div class="row">
  <div class="col-md-8">
    <div class="card shadow-sm">
      <div class="card-header d-flex justify-content-between"><h6 class="mb-0">Recent Orders</h6><a href="orders.php" class="btn btn-sm btn-primary">View All</a></div>
      <div class="card-body">
        <table class="table table-sm">
          <thead><tr><th>ID</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th></tr></thead>
          <tbody>
          <?php foreach($recentOrders as $o): ?>
            <tr><td>#<?= $o['id'] ?></td><td><?= sanitize($o['user_name']) ?></td><td>Rs.<?= number_format($o['total_amount'],2) ?></td><td><span class="badge bg-warning"><?= $o['status'] ?></span></td><td><?= date('d M', strtotime($o['created_at'])) ?></td></tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card shadow-sm">
      <div class="card-body">
        <h6>System Info</h6>
        <p class="small text-muted mb-1">Assignment: SE102.3 Web Based Application Development</p>
        <p class="small text-muted mb-1">Module Leader: S.Naji</p>
        <p class="small text-muted">Deliverables: Website + Report</p>
        <hr>
        <h6>Quick Actions</h6>
        <a href="products.php" class="btn btn-outline-primary btn-sm w-100 mb-2">Manage Products (DML)</a>
        <a href="categories.php" class="btn btn-outline-success btn-sm w-100 mb-2">Manage Categories</a>
        <a href="orders.php" class="btn btn-outline-warning btn-sm w-100">Manage Orders</a>
      </div>
    </div>
  </div>
</div>
<?php require_once '../includes/admin_footer.php'; ?>
