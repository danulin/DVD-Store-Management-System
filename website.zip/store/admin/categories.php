<?php
require_once '../config/config.php';
requireAdmin();

if(isset($_GET['delete'])){
    $id=(int)$_GET['delete'];
    $db->prepare("DELETE FROM categories WHERE id=:id")->execute([':id'=>$id]);
    header("Location: categories.php?deleted=1");
    exit;
}
if($_SERVER['REQUEST_METHOD']=='POST'){
    if(isset($_POST['add'])){
        $name=sanitize($_POST['name']);
        $desc=sanitize($_POST['description']);
        $slug=generateSlug($name).'-'.time();
        $db->prepare("INSERT INTO categories (name, slug, description) VALUES (:name, :slug, :desc)")->execute([':name'=>$name, ':slug'=>$slug, ':desc'=>$desc]);
        header("Location: categories.php?added=1");
        exit;
    }
    if(isset($_POST['edit'])){
        $id=(int)$_POST['id'];
        $name=sanitize($_POST['name']);
        $desc=sanitize($_POST['description']);
        $db->prepare("UPDATE categories SET name=:name, description=:desc WHERE id=:id")->execute([':name'=>$name, ':desc'=>$desc, ':id'=>$id]);
        header("Location: categories.php?updated=1");
        exit;
    }
}
require_once '../includes/admin_header.php';
$cats = $db->query("SELECT * FROM categories ORDER BY id DESC")->fetchAll();
?>
<h4>Categories Management</h4>
<?php if(isset($_GET['added'])): ?><div class="alert alert-success">Category added (INSERT)</div><?php endif; ?>
<?php if(isset($_GET['updated'])): ?><div class="alert alert-info">Category updated (UPDATE)</div><?php endif; ?>
<?php if(isset($_GET['deleted'])): ?><div class="alert alert-warning">Category deleted (DELETE)</div><?php endif; ?>

<div class="row">
<div class="col-md-4">
  <div class="card shadow-sm">
    <div class="card-body">
      <h6>Add New Category</h6>
      <form method="POST">
        <div class="mb-3"><label>Name</label><input type="text" name="name" class="form-control" required></div>
        <div class="mb-3"><label>Description</label><textarea name="description" class="form-control"></textarea></div>
        <button type="submit" name="add" class="btn btn-primary w-100">Add Category</button>
      </form>
    </div>
  </div>
</div>
<div class="col-md-8">
  <div class="card shadow-sm">
    <div class="card-body table-responsive">
      <table class="table">
        <thead><tr><th>ID</th><th>Name</th><th>Slug</th><th>Actions</th></tr></thead>
        <tbody>
        <?php foreach($cats as $c): ?>
        <tr>
          <td><?= $c['id'] ?></td>
          <td><?= sanitize($c['name']) ?></td>
          <td><small><?= $c['slug'] ?></small></td>
          <td>
            <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#edit<?= $c['id'] ?>">Edit</button>
            <a href="categories.php?delete=<?= $c['id'] ?>" onclick="return confirm('Delete?')" class="btn btn-sm btn-outline-danger">Delete</a>
          </td>
        </tr>
        <!-- Modal -->
        <div class="modal fade" id="edit<?= $c['id'] ?>" tabindex="-1"><div class="modal-dialog"><div class="modal-content">
          <form method="POST"><div class="modal-header"><h5>Edit Category</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
          <div class="modal-body">
            <input type="hidden" name="id" value="<?= $c['id'] ?>">
            <div class="mb-3"><label>Name</label><input type="text" name="name" class="form-control" value="<?= sanitize($c['name']) ?>" required></div>
            <div class="mb-3"><label>Description</label><textarea name="description" class="form-control"><?= sanitize($c['description']) ?></textarea></div>
          </div>
          <div class="modal-footer"><button type="submit" name="edit" class="btn btn-primary">Update</button></div>
          </form>
        </div></div></div>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</div>
<?php require_once '../includes/admin_footer.php'; ?>
