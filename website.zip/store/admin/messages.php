<?php
require_once '../config/config.php';
requireAdmin();

if(isset($_GET['delete'])){
    $id=(int)$_GET['delete'];
    $db->prepare("DELETE FROM contact_messages WHERE id=:id")->execute([':id'=>$id]);
    header("Location: messages.php?deleted=1");
    exit;
}
if(isset($_POST['mark_read'])){
    $id=(int)$_POST['msg_id'];
    $db->prepare("UPDATE contact_messages SET status='read' WHERE id=:id")->execute([':id'=>$id]);
    header("Location: messages.php?updated=1");
    exit;
}

require_once '../includes/admin_header.php';
$msgs = $db->query("SELECT * FROM contact_messages ORDER BY created_at DESC")->fetchAll();
?>
<h4>Contact Messages (Customer Inquiry)</h4>
<?php if(isset($_GET['deleted'])): ?><div class="alert alert-warning">Message deleted</div><?php endif; ?>
<?php if(isset($_GET['updated'])): ?><div class="alert alert-success">Marked as read</div><?php endif; ?>

<div class="card shadow-sm mt-3">
<div class="card-body table-responsive">
<table class="table">
<thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Subject</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
<tbody>
<?php foreach($msgs as $m): ?>
<tr>
  <td><?= $m['id'] ?></td>
  <td><?= sanitize($m['name']) ?></td>
  <td><?= sanitize($m['email']) ?></td>
  <td><?= sanitize($m['subject']) ?></td>
  <td><span class="badge bg-<?= $m['status']=='read'?'success':'warning' ?>"><?= $m['status'] ?></span></td>
  <td><?= date('d M Y', strtotime($m['created_at'])) ?></td>
  <td>
    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#msg<?= $m['id'] ?>">View</button>
    <a href="messages.php?delete=<?= $m['id'] ?>" onclick="return confirm('Delete?')" class="btn btn-sm btn-outline-danger">Delete</a>
  </td>
</tr>
<div class="modal fade" id="msg<?= $m['id'] ?>" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><h5>Message #<?= $m['id'] ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body">
<p><strong>From:</strong> <?= sanitize($m['name']) ?> (<?= sanitize($m['email']) ?>)</p>
<p><strong>Subject:</strong> <?= sanitize($m['subject']) ?></p>
<p><strong>Message:</strong><br><?= nl2br(sanitize($m['message'])) ?></p>
<form method="POST"><?php if($m['status']=='unread'): ?><input type="hidden" name="msg_id" value="<?= $m['id'] ?>"><button type="submit" name="mark_read" class="btn btn-sm btn-success">Mark as Read (UPDATE)</button><?php endif; ?></form>
</div></div></div></div>
<?php endforeach; ?>
</tbody>
</table>
</div>
</div>
<?php require_once '../includes/admin_footer.php'; ?>
