<?php
require_once '../config/config.php';
requireAdmin();
$categories = $db->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$error='';
if($_SERVER['REQUEST_METHOD']=='POST'){
    $name = sanitize($_POST['name']);
    $cat = (int)$_POST['category_id'];
    $desc = sanitize($_POST['description']);
    $price = (float)$_POST['price'];
    $stock = (int)$_POST['stock'];
    $image = trim($_POST['image_url']);
    $status = $_POST['status'];
    $slug = generateSlug($name).'-'.time();
    
    // INSERT DML
    $stmt = $db->prepare("INSERT INTO products (category_id, name, slug, description, price, stock_quantity, image_url, status) VALUES (:cat, :name, :slug, :desc, :price, :stock, :img, :status)");
    if($stmt->execute([':cat'=>$cat, ':name'=>$name, ':slug'=>$slug, ':desc'=>$desc, ':price'=>$price, ':stock'=>$stock, ':img'=>$image, ':status'=>$status])){
        header("Location: products.php?added=1");
        exit;
    } else {
        $error="Failed to add";
    }
}
require_once '../includes/admin_header.php';
?>
<h4>Add New Product - INSERT Operation</h4>
<?php if($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
<div class="card shadow-sm mt-3">
<div class="card-body">
<form method="POST">
  <div class="row g-3">
    <div class="col-md-6"><label class="form-label">Product Name</label><input type="text" name="name" class="form-control" required></div>
    <div class="col-md-6"><label class="form-label">Category</label><select name="category_id" class="form-select" required><option value="">Select</option><?php foreach($categories as $c): ?><option value="<?= $c['id'] ?>"><?= sanitize($c['name']) ?></option><?php endforeach; ?></select></div>
    <div class="col-md-4"><label class="form-label">Price (Rs.)</label><input type="number" step="0.01" name="price" class="form-control" required></div>
    <div class="col-md-4"><label class="form-label">Stock Quantity</label><input type="number" name="stock" class="form-control" required></div>
    <div class="col-md-4"><label class="form-label">Status</label><select name="status" class="form-select"><option value="active">Active</option><option value="inactive">Inactive</option></select></div>
    <div class="col-12"><label class="form-label">Image URL</label><input type="url" name="image_url" class="form-control" placeholder="https://... or leave empty for placeholder"></div>
    <div class="col-12"><label class="form-label">Description</label><textarea name="description" class="form-control" rows="4" required></textarea></div>
    <div class="col-12"><button class="btn btn-primary">Add Product</button> <a href="products.php" class="btn btn-secondary">Cancel</a></div>
  </div>
</form>
</div>
</div>
<?php require_once '../includes/admin_footer.php'; ?>
