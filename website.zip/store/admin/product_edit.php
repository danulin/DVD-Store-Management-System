<?php
require_once '../config/config.php';
requireAdmin();
if(!isset($_GET['id'])){ header("Location: products.php"); exit; }
$id=(int)$_GET['id'];
$stmt=$db->prepare("SELECT * FROM products WHERE id=:id");
$stmt->execute([':id'=>$id]);
$product=$stmt->fetch();
if(!$product){ header("Location: products.php"); exit; }

$categories = $db->query("SELECT * FROM categories ORDER BY name")->fetchAll();

if($_SERVER['REQUEST_METHOD']=='POST'){
    $name = sanitize($_POST['name']);
    $cat = (int)$_POST['category_id'];
    $desc = sanitize($_POST['description']);
    $price = (float)$_POST['price'];
    $stock = (int)$_POST['stock'];
    $image = trim($_POST['image_url']);
    $status = $_POST['status'];
    
    // UPDATE DML
    $stmt = $db->prepare("UPDATE products SET category_id=:cat, name=:name, description=:desc, price=:price, stock_quantity=:stock, image_url=:img, status=:status, updated_at=NOW() WHERE id=:id");
    $stmt->execute([':cat'=>$cat, ':name'=>$name, ':desc'=>$desc, ':price'=>$price, ':stock'=>$stock, ':img'=>$image, ':status'=>$status, ':id'=>$id]);
    header("Location: products.php?updated=1");
    exit;
}
require_once '../includes/admin_header.php';
?>
<h4>Edit Product - UPDATE Operation (ID: <?= $id ?>)</h4>
<div class="card shadow-sm mt-3">
<div class="card-body">
<form method="POST">
  <div class="row g-3">
    <div class="col-md-6"><label class="form-label">Product Name</label><input type="text" name="name" class="form-control" required value="<?= sanitize($product['name']) ?>"></div>
    <div class="col-md-6"><label class="form-label">Category</label><select name="category_id" class="form-select" required><?php foreach($categories as $c): ?><option value="<?= $c['id'] ?>" <?= $product['category_id']==$c['id']?'selected':'' ?>><?= sanitize($c['name']) ?></option><?php endforeach; ?></select></div>
    <div class="col-md-4"><label class="form-label">Price</label><input type="number" step="0.01" name="price" class="form-control" required value="<?= $product['price'] ?>"></div>
    <div class="col-md-4"><label class="form-label">Stock</label><input type="number" name="stock" class="form-control" required value="<?= $product['stock_quantity'] ?>"></div>
    <div class="col-md-4"><label class="form-label">Status</label><select name="status" class="form-select"><option value="active" <?= $product['status']=='active'?'selected':'' ?>>Active</option><option value="inactive" <?= $product['status']=='inactive'?'selected':'' ?>>Inactive</option></select></div>
    <div class="col-12"><label class="form-label">Image URL</label><input type="url" name="image_url" class="form-control" value="<?= sanitize($product['image_url']) ?>"></div>
    <div class="col-12"><label class="form-label">Description</label><textarea name="description" class="form-control" rows="4" required><?= sanitize($product['description']) ?></textarea></div>
    <div class="col-12"><button class="btn btn-primary">Update Product</button> <a href="products.php" class="btn btn-secondary">Cancel</a></div>
  </div>
</form>
</div>
</div>
<?php require_once '../includes/admin_footer.php'; ?>
