<?php
require_once '../config/config.php';
requireAdmin();

if(isset($_POST['update_status'])){
    $oid=(int)$_POST['order_id'];
    $status=$_POST['status'];
    $db->prepare("UPDATE orders SET status=:status WHERE id=:id")->execute([':status'=>$status, ':id'=>$oid]);
    header("Location: orders.php?updated=1");
    exit;
}
if(isset($_GET['delete'])){
    $oid=(int)$_GET['delete'];
    $db->prepare("DELETE FROM order_items WHERE order_id=:id")->execute([':id'=>$oid]);
    $db->prepare("DELETE FROM orders WHERE id=:id")->execute([':id'=>$oid]);
    header("Location: orders.php?deleted=1");
    exit;
}

require_once '../includes/admin_header.php';
$orders = $db->query("SELECT o.*, u.name as user_name, u.email FROM orders o JOIN users u ON o.user_id=u.id ORDER BY o.created_at DESC")->fetchAll();
?>
<h4>Orders Management - SELECT & UPDATE & DELETE</h4>
<?php if(isset($_GET['updated'])): ?><div class="alert alert-success">Order status updated (UPDATE DML)</div><?php endif; ?>
<?php if(isset($_GET['deleted'])): ?><div class="alert alert-warning">Order deleted (DELETE DML)</div><?php endif; ?>

<div class="card shadow-sm mt-3">
<div class="card-body table-responsive">
<table class="table">
<thead><tr><th>ID</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
<tbody>
<?php foreach($orders as $o): ?>
<tr>
  <td>#<?= $o['id'] ?></td>
  <td><?= sanitize($o['user_name']) ?><br><small><?= sanitize($o['email']) ?></small></td>
  <td>Rs.<?= number_format($o['total_amount'],2) ?></td>
  <td><span class="badge bg-<?= $o['status']=='pending'?'warning':($o['status']=='completed'?'success':'info') ?>"><?= $o['status'] ?></span></td>
  <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
  <td>
    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#order<?= $o['id'] ?>">View</button>
    <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#status<?= $o['id'] ?>">Status</button>
    <a href="orders.php?delete=<?= $o['id'] ?>" onclick="return confirm('Delete order?')" class="btn btn-sm btn-outline-danger">Delete</a>
  </td>
</tr>

<!-- View Modal -->
<div class="modal fade" id="order<?= $o['id'] ?>" tabindex="-1"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header"><h5>Order #<?= $o['id'] ?> Details (SELECT JOIN)</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body">
<?php
$items = $db->prepare("SELECT oi.*, p.name FROM order_items oi JOIN products p ON oi.product_id=p.id WHERE oi.order_id=:oid");
$items->execute([':oid'=>$o['id']]);
$items = $items->fetchAll();
?>
<p><strong>Customer:</strong> <?= sanitize($o['shipping_name']) ?> | <?= sanitize($o['shipping_phone']) ?><br><strong>Address:</strong> <?= sanitize($o['shipping_address']) ?></p>
<table class="table table-sm"><thead><tr><th>Product</th><th>Qty</th><th>Price</th><th>Subtotal</th></tr></thead><tbody>
<?php foreach($items as $it): ?><tr><td><?= sanitize($it['name']) ?></td><td><?= $it['quantity'] ?></td><td>Rs.<?= $it['price'] ?></td><td>Rs.<?= number_format($it['price']*$it['quantity'],2) ?></td></tr><?php endforeach; ?>
</tbody></table>
<p class="fw-bold text-end">Total: Rs.<?= number_format($o['total_amount'],2) ?></p>
</div></div></div></div>

<!-- Status Modal -->
<div class="modal fade" id="status<?= $o['id'] ?>" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><form method="POST"><div class="modal-header"><h5>Update Status - UPDATE</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body">
<input type="hidden" name="order_id" value="<?= $o['id'] ?>">
<select name="status" class="form-select"><option value="pending" <?= $o['status']=='pending'?'selected':'' ?>>Pending</option><option value="processing" <?= $o['status']=='processing'?'selected':'' ?>>Processing</option><option value="completed" <?= $o['status']=='completed'?'selected':'' ?>>Completed</option><option value="cancelled" <?= $o['status']=='cancelled'?'selected':'' ?>>Cancelled</option></select>
</div><div class="modal-footer"><button type="submit" name="update_status" class="btn btn-primary">Update</button></div></form></div></div></div>

<?php endforeach; ?>
</tbody>
</table>
</div>
</div>
<?php require_once '../includes/admin_footer.php'; ?>
