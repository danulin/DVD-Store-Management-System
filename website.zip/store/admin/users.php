<?php
require_once '../config/config.php';
requireAdmin();

if(isset($_GET['delete'])){
    $id=(int)$_GET['delete'];
    if($id != $_SESSION['user_id']){
        $db->prepare("DELETE FROM users WHERE id=:id")->execute([':id'=>$id]);
    }
    header("Location: users.php?deleted=1");
    exit;
}
if(isset($_POST['update_role'])){
    $uid=(int)$_POST['user_id'];
    $role=$_POST['role'];
    $db->prepare("UPDATE users SET role=:role WHERE id=:id")->execute([':role'=>$role, ':id'=>$uid]);
    header("Location: users.php?updated=1");
    exit;
}

require_once '../includes/admin_header.php';
$users = $db->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();
?>
<h4>Users Management</h4>
<?php if(isset($_GET['deleted'])): ?><div class="alert alert-warning">User deleted (DELETE)</div><?php endif; ?>
<?php if(isset($_GET['updated'])): ?><div class="alert alert-success">User role updated (UPDATE)</div><?php endif; ?>

<div class="card shadow-sm mt-3">
<div class="card-body table-responsive">
<table class="table">
<thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Joined</th><th>Actions</th></tr></thead>
<tbody>
<?php foreach($users as $u): ?>
<tr>
  <td><?= $u['id'] ?></td>
  <td><?= sanitize($u['name']) ?></td>
  <td><?= sanitize($u['email']) ?></td>
  <td><span class="badge bg-<?= $u['role']=='admin'?'danger':'primary' ?>"><?= $u['role'] ?></span></td>
  <td><?= date('d M Y', strtotime($u['created_at'])) ?></td>
  <td>
    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#role<?= $u['id'] ?>">Edit Role</button>
    <?php if($u['id'] != $_SESSION['user_id']): ?><a href="users.php?delete=<?= $u['id'] ?>" onclick="return confirm('Delete user?')" class="btn btn-sm btn-outline-danger">Delete</a><?php endif; ?>
  </td>
</tr>
<div class="modal fade" id="role<?= $u['id'] ?>" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><form method="POST"><div class="modal-header"><h5>Update Role</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body">
<input type="hidden" name="user_id" value="<?= $u['id'] ?>">
<select name="role" class="form-select"><option value="customer" <?= $u['role']=='customer'?'selected':'' ?>>Customer</option><option value="admin" <?= $u['role']=='admin'?'selected':'' ?>>Admin</option></select>
</div><div class="modal-footer"><button type="submit" name="update_role" class="btn btn-primary">Update</button></div></form></div></div></div>
<?php endforeach; ?>
</tbody>
</table>
</div>
</div>
<?php require_once '../includes/admin_footer.php'; ?>
