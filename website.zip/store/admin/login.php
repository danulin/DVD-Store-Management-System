<?php
require_once '../config/config.php';
if(isAdmin()){ header("Location: index.php"); exit; }
header("Location: ../login.php");
exit;
?>