<?php
require_once '../config/config.php';
requireAdmin();

if(isset($_GET['delete'])){
    $id=(int)$_GET['delete'];
    $stmt=$db->prepare("DELETE FROM products WHERE id=:id");
    $stmt->execute([':id'=>$id]);
    header("Location: products.php?deleted=1");
    exit;
}

require_once '../includes/admin_header.php';
$products = $db->query("SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id=c.id ORDER BY p.created_at DESC")->fetchAll();
?>
<div class="d-flex justify-content-between align-items-center mb-4">
  <h4>Products Management (All DML Operations)</h4>
  <a href="product_add.php" class="btn btn-primary"><i class="bi bi-plus"></i> Add Product (INSERT)</a>
</div>
<?php if(isset($_GET['deleted'])): ?><div class="alert alert-success">Product deleted (DELETE operation)</div><?php endif; ?>
<?php if(isset($_GET['added'])): ?><div class="alert alert-success">Product added (INSERT operation)</div><?php endif; ?>
<?php if(isset($_GET['updated'])): ?><div class="alert alert-info">Product updated (UPDATE operation)</div><?php endif; ?>

<div class="card shadow-sm">
<div class="card-body table-responsive">
<table class="table table-striped align-middle">
<thead><tr><th>ID</th><th>Image</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr></thead>
<tbody>
<?php foreach($products as $p): ?>
<tr>
  <td><?= $p['id'] ?></td>
  <td><img src="<?= $p['image_url'] ?: 'https://via.placeholder.com/50' ?>" width="50" height="50" style="object-fit:cover" class="rounded"></td>
  <td><?= sanitize($p['name']) ?></td>
  <td><?= sanitize($p['cat_name']) ?></td>
  <td>Rs.<?= number_format($p['price'],2) ?></td>
  <td><?= $p['stock_quantity'] ?></td>
  <td><span class="badge bg-<?= $p['status']=='active'?'success':'secondary' ?>"><?= $p['status'] ?></span></td>
  <td>
    <a href="product_edit.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-primary">Edit (UPDATE)</a>
    <a href="products.php?delete=<?= $p['id'] ?>" onclick="return confirm('Delete this product?')" class="btn btn-sm btn-outline-danger">Delete</a>
  </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
</div>
<?php require_once '../includes/admin_footer.php'; ?>
