</main>
<footer class="footer-premium">
    <div class="footer-top">
        <div class="container">
            <div class="row g-4 g-lg-5">
                <!-- Brand -->
                <div class="col-lg-4 col-md-6">
                    <a href="<?= BASE_URL ?>/index.php" class="footer-brand">
                        <img src="<?= BASE_URL ?>/assets/images/logo.png" alt="TechMart" style="height:38px; width:auto; filter: brightness(0) invert(1);">
                    </a>
                    <p class="footer-desc">
                        Your trusted online electronics & lifestyle store in Sri Lanka. Quality products, fast delivery, and 1-year warranty.
                    </p>
                    <div class="social-links">
                        <a href="#" class="social-btn"><i class="bi bi-facebook"></i></a>
                        <a href="#" class="social-btn"><i class="bi bi-instagram"></i></a>
                        <a href="#" class="social-btn"><i class="bi bi-tiktok"></i></a>
                        <a href="#" class="social-btn"><i class="bi bi-youtube"></i></a>
                    </div>
                </div>

                <!-- Quick Links -->
                <div class="col-lg-2 col-6">
                    <h6 class="footer-title">Shop</h6>
                    <ul class="footer-links">
                        <li><a href="<?= BASE_URL ?>/index.php">Home</a></li>
                        <li><a href="<?= BASE_URL ?>/shop.php">All Products</a></li>
                        <li><a href="<?= BASE_URL ?>/shop.php?category=1">Smartphones</a></li>
                        <li><a href="<?= BASE_URL ?>/shop.php?category=2">Laptops</a></li>
                        <li><a href="<?= BASE_URL ?>/about.php">About Us</a></li>
                    </ul>
                </div>

                <!-- Support -->
                <div class="col-lg-2 col-6">
                    <h6 class="footer-title">Support</h6>
                    <ul class="footer-links">
                        <li><a href="<?= BASE_URL ?>/contact.php">Contact Us</a></li>
                        <li><a href="#">Track Order</a></li>
                        <li><a href="#">Shipping Info</a></li>
                        <li><a href="#">Returns & Refunds</a></li>
                        <li><a href="#">FAQs</a></li>
                    </ul>
                </div>

                <!-- Contact + Newsletter -->
                <div class="col-lg-4 col-md-6">
                    <h6 class="footer-title">Stay in the loop</h6>
                    <p class="footer-desc small mb-3">Get 10% off your first order. No spam, unsubscribe anytime.</p>
                    <form class="newsletter-form" onsubmit="event.preventDefault(); alert('Thanks for subscribing!');">
                        <input type="email" placeholder="Enter your email" required>
                        <button type="submit">Subscribe</button>
                    </form>
                    <div class="contact-info mt-4">
                        <div class="contact-item"><i class="bi bi-telephone"></i> +94 11 234 5678</div>
                        <div class="contact-item"><i class="bi bi-envelope"></i> support@techmart.lk</div>
                        <div class="contact-item"><i class="bi bi-geo-alt"></i> Colombo, Sri Lanka • Island-wide delivery</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="footer-bottom">
        <div class="container">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3">
                <p class="mb-0 small">&copy; <?= date('Y') ?> TechMart. All rights reserved.</p>
                <div class="d-flex align-items-center gap-3">
                    <span class="small" style="color:#94a3b8;">We accept:</span>
                    <div class="payment-icons">
                        <span class="pay-icon"><i class="bi bi-credit-card"></i></span>
                        <span class="pay-icon"><i class="bi bi-paypal"></i></span>
                        <span class="pay-icon">VISA</span>
                        <span class="pay-icon">MC</span>
                    </div>
                </div>
                <div class="d-flex gap-3 small">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms of Service</a>
                </div>
            </div>
        </div>
    </div>
</footer>

<style>
    .footer-premium { background:#0f172a; color:#cbd5e1; margin-top:80px; position:relative; overflow:hidden; }
    .footer-premium::before { content:''; position:absolute; width:600px; height:600px; background:radial-gradient(circle, rgba(99,102,241,0.15) 0%, transparent 70%); top:-200px; right:-200px; pointer-events:none; }
    .footer-top { padding:60px 0 40px; }
    .footer-brand { display:inline-flex; align-items:center; gap:10px; font-family:'Plus Jakarta Sans'; font-weight:800; font-size:22px; color:white; text-decoration:none; margin-bottom:16px; }
    .footer-desc { color:#94a3b8; font-size:14px; line-height:1.6; max-width:320px; }
    .footer-title { color:white; font-family:'Plus Jakarta Sans'; font-weight:700; font-size:13px; letter-spacing:0.06em; text-transform:uppercase; margin-bottom:18px; }
    .footer-links { list-style:none; padding:0; margin:0; }
    .footer-links li { margin-bottom:10px; }
    .footer-links a { color:#94a3b8; text-decoration:none; font-size:14px; transition:all 0.2s; }
    .footer-links a:hover { color:white; transform:translateX(3px); display:inline-block; }
    .social-links { display:flex; gap:8px; margin-top:20px; }
    .social-btn { width:38px; height:38px; border-radius:10px; background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.08); display:flex; align-items:center; justify-content:center; color:#94a3b8; text-decoration:none; transition:all 0.2s; }
    .social-btn:hover { background:white; color:#0f172a; transform:translateY(-2px); }
    .newsletter-form { display:flex; background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.08); border-radius:14px; padding:4px; backdrop-filter:blur(10px); }
    .newsletter-form input { flex:1; background:transparent; border:none; color:white; padding:10px 14px; font-size:14px; outline:none; }
    .newsletter-form input::placeholder { color:#64748b; }
    .newsletter-form button { background:white; color:#0f172a; border:none; border-radius:10px; padding:10px 18px; font-weight:700; font-size:13px; transition:all 0.2s; }
    .newsletter-form button:hover { background:#e2e8f0; }
    .contact-info { display:flex; flex-direction:column; gap:8px; }
    .contact-item { display:flex; align-items:center; gap:8px; font-size:13px; color:#94a3b8; }
    .contact-item i { color:#6366f1; }
    .footer-bottom { border-top:1px solid rgba(255,255,255,0.08); padding:20px 0; }
    .footer-bottom a { color:#94a3b8; text-decoration:none; }
    .footer-bottom a:hover { color:white; }
    .payment-icons { display:flex; gap:6px; }
    .pay-icon { width:40px; height:26px; background:rgba(255,255,255,0.08); border:1px solid rgba(255,255,255,0.08); border-radius:6px; display:flex; align-items:center; justify-content:center; font-size:10px; font-weight:700; color:#cbd5e1; }
</style>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
</body>
</html>
