<?php
require_once __DIR__ . '/../config/config.php';
requireAdmin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin - <?= SITE_NAME ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
.admin-sidebar{min-height:100vh;background:#212529}
.admin-sidebar .nav-link{color:#adb5bd}
.admin-sidebar .nav-link.active,.admin-sidebar .nav-link:hover{color:white;background:#0d6efd;border-radius:6px}
</style>
</head>
<body>
<div class="container-fluid">
<div class="row">
<div class="col-md-2 p-0 admin-sidebar">
  <div class="p-3 text-white">
    <h5 class="fw-bold"><i class="bi bi-speedometer2"></i> TechMart Admin</h5>
    <small class="text-white-50"><?= sanitize($_SESSION['user_name']) ?></small>
  </div>
  <nav class="nav flex-column p-2 gap-1">
    <a class="nav-link" href="index.php"><i class="bi bi-graph-up"></i> Dashboard</a>
    <a class="nav-link" href="products.php"><i class="bi bi-box-seam"></i> Products</a>
    <a class="nav-link" href="categories.php"><i class="bi bi-tags"></i> Categories</a>
    <a class="nav-link" href="orders.php"><i class="bi bi-receipt"></i> Orders</a>
    <a class="nav-link" href="users.php"><i class="bi bi-people"></i> Users</a>
    <a class="nav-link" href="messages.php"><i class="bi bi-envelope"></i> Messages</a>
    <hr class="bg-secondary">
    <a class="nav-link" href="../index.php" target="_blank"><i class="bi bi-globe"></i> View Site</a>
    <a class="nav-link" href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
  </nav>
</div>
<div class="col-md-10 p-4">
