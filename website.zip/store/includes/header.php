<?php
if (session_status() == PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../config/database.php';
if (!isset($db)) {
    $database = new Database();
    $db = $database->getConnection();
}
require_once __DIR__ . '/functions.php';
$cart = $_SESSION['cart'] ?? [];
$cartCount = getCartCount();
$cartTotal = 0;
foreach($cart as $it) { $cartTotal += $it['price'] * $it['quantity']; }

/* ------------------------------------------------------------------
   LOGO + BASE PATH (works from any page, including /admin pages)
   Project structure:  store/assets/images/logo.png
------------------------------------------------------------------- */
if (defined('BASE_URL')) {
    $siteBase = rtrim(BASE_URL, '/');
} else {
    // Auto-detect e.g. "/store" from the folder location on disk
    $projectRoot = str_replace('\\', '/', realpath(__DIR__ . '/..'));
    $docRoot     = str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT']));
    $siteBase    = rtrim(str_replace($docRoot, '', $projectRoot), '/');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? $pageTitle . ' - ' . SITE_NAME : (defined('SITE_NAME') ? SITE_NAME : 'TechMart') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <link href="<?= $siteBase ?>/assets/css/style.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="/assets/images/logo.png">
    <style>
        :root {
            --primary: #6366f1; --primary-dark: #4f46e5; --dark: #0f172a;
            --gray-500: #64748b; --radius-xl: 16px;
        }
        body { font-family: 'Inter', sans-serif; -webkit-font-smoothing: antialiased; }

        /* Top Bar */
        .top-bar { background: var(--dark); color: #cbd5e1; font-size: 13px; padding: 8px 0; }
        .top-bar a { color: white; text-decoration: none; font-weight: 500; }

        /* Navbar - Glassmorphism with Logo */
        .navbar-premium {
            background: rgba(255,255,255,0.85) !important;
            backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px);
            border-bottom: 1px solid #f1f5f9; padding: 10px 0; transition: all 0.3s;
        }
        .navbar-premium.scrolled { box-shadow: 0 10px 40px rgba(15,23,42,0.06); background: rgba(255,255,255,0.95) !important; }

        /* LOGO STYLES */
        .brand-logo {
            display: flex; align-items: center; gap: 10px;
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-weight: 800; font-size: 22px; letter-spacing: -0.03em;
            color: var(--dark); text-decoration: none;
        }
        .brand-logo img {
            height: 80px; width: auto; max-width: 240px; object-fit: contain;
            transition: transform 0.3s;
        }
        .brand-logo:hover img { transform: scale(1.05); }
        .brand-logo-fallback {
            width: 36px; height: 36px; border-radius: 10px;
            background: linear-gradient(135deg, var(--primary) 0%, #8b5cf6 100%);
            display: flex; align-items: center; justify-content: center;
            color: white; font-size: 18px; box-shadow: 0 6px 16px rgba(99,102,241,0.3);
        }

        /* Nav Links */
        .nav-link-premium {
            font-weight: 500; font-size: 14.5px; color: #334155 !important;
            padding: 8px 14px !important; border-radius: 10px; transition: all 0.2s;
        }
        .nav-link-premium:hover { background: #f8fafc; color: var(--dark) !important; }
        .nav-link-premium.active { background: #eef2ff; color: var(--primary) !important; font-weight: 600; }

        /* Search */
        .search-wrap { position: relative; width: 300px; }
        .search-input {
            width: 100%; background: #f8fafc; border: 1px solid #f1f5f9;
            border-radius: 100px; padding: 9px 16px 9px 40px; font-size: 14px; transition: all 0.3s;
        }
        .search-input:focus { background: white; border-color: var(--primary); box-shadow: 0 0 0 4px rgba(99,102,241,0.1); outline: none; }
        .search-icon { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: #94a3b8; }

        /* Cart */
        .cart-btn {
            position: relative; width: 42px; height: 42px; border-radius: 12px;
            background: #f8fafc; border: 1px solid #f1f5f9;
            display: flex; align-items: center; justify-content: center;
            color: var(--dark); transition: all 0.2s; text-decoration: none;
        }
        .cart-btn:hover { background: var(--dark); color: white; border-color: var(--dark); transform: translateY(-1px); }
        .cart-badge {
            position: absolute; top: -6px; right: -6px; background: #ef4444; color: white;
            font-size: 11px; font-weight: 700; min-width: 20px; height: 20px; border-radius: 100px;
            display: flex; align-items: center; justify-content: center; border: 2px solid white;
        }
        .cart-preview {
            position: absolute; top: calc(100% + 12px); right: 0; width: 360px; background: white;
            border-radius: 20px; box-shadow: 0 20px 60px rgba(15,23,42,0.15); border: 1px solid #f1f5f9;
            opacity: 0; visibility: hidden; transform: translateY(10px);
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); z-index: 1000;
        }
        .cart-trigger:hover .cart-preview { opacity: 1; visibility: visible; transform: translateY(0); }
        .cart-item { display: flex; gap: 12px; padding: 12px 18px; border-bottom: 1px solid #f8fafc; }
        .cart-item img { width: 48px; height: 48px; border-radius: 10px; object-fit: cover; background: #f8fafc; }

        /* User Menu */
        .user-trigger {
            display: flex; align-items: center; gap: 10px; background: #f8fafc;
            border: 1px solid #f1f5f9; border-radius: 100px; padding: 4px 6px 4px 12px; cursor: pointer;
        }
        .avatar {
            width: 32px; height: 32px; border-radius: 50%;
            background: linear-gradient(135deg, #6366f1, #8b5cf6); color: white;
            display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 13px;
        }
        .user-dropdown {
            position: absolute; top: calc(100% + 10px); right: 0; width: 240px; background: white;
            border-radius: 16px; box-shadow: 0 20px 60px rgba(15,23,42,0.12); border: 1px solid #f1f5f9;
            padding: 8px; opacity: 0; visibility: hidden; transform: translateY(8px); transition: all 0.25s; z-index: 1000;
        }
        .user-menu-wrap:hover .user-dropdown { opacity: 1; visibility: visible; transform: translateY(0); }
        .dropdown-item-premium {
            display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 10px;
            font-size: 14px; font-weight: 500; color: #334155; text-decoration: none;
        }
        .dropdown-item-premium:hover { background: #f8fafc; color: var(--dark); }
        .btn-register {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white; border: none; border-radius: 100px; padding: 9px 18px; font-weight: 600; font-size: 14px;
            box-shadow: 0 6px 16px rgba(99,102,241,0.25); transition: all 0.2s;
        }
        .btn-register:hover { transform: translateY(-1px); color: white; }
    </style>
</head>
<body>

<div class="top-bar d-none d-md-block">
    <div class="container d-flex justify-content-between align-items-center">
        <div class="d-flex gap-4">
            <span><i class="bi bi-truck me-1"></i> Free delivery over Rs. 5,000 island-wide</span>
            <span class="d-none d-lg-inline"><i class="bi bi-telephone me-1"></i> Hotline: +94 11 234 5678</span>
        </div>
        <div class="d-flex gap-3">
            <a href="about.php">Track Order</a>
            <a href="contact.php">Support</a>
        </div>
    </div>
</div>

<nav class="navbar navbar-expand-lg navbar-premium sticky-top" id="mainNav">
    <div class="container">

        <!-- LOGO -->
        <a class="brand-logo" href="<?= $siteBase ?>/index.php">
            <img src="./assets/images/logo.png" alt="TechMart Logo">

        </a>

        <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <i class="bi bi-list fs-3"></i>
        </button>

        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav mx-auto gap-1 my-3 my-lg-0">
                <?php $current = basename($_SERVER['PHP_SELF']); ?>
                <li class="nav-item"><a class="nav-link nav-link-premium <?= $current=='index.php'?'active':'' ?>" href="<?= $siteBase ?>/index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link nav-link-premium <?= $current=='shop.php'?'active':'' ?>" href="<?= $siteBase ?>/shop.php">Shop</a></li>
                <li class="nav-item"><a class="nav-link nav-link-premium <?= $current=='about.php'?'active':'' ?>" href="<?= $siteBase ?>/about.php">About</a></li>
                <li class="nav-item"><a class="nav-link nav-link-premium <?= $current=='contact.php'?'active':'' ?>" href="<?= $siteBase ?>/contact.php">Contact</a></li>
            </ul>

            <div class="d-flex align-items-center gap-2 gap-lg-3">
                <form action="<?= $siteBase ?>/shop.php" method="GET" class="search-wrap d-none d-lg-block">
                    <i class="bi bi-search search-icon"></i>
                    <input type="text" name="search" class="search-input" placeholder="Search iPhone, MacBook..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                </form>

                <div class="position-relative cart-trigger">
                    <a href="<?= $siteBase ?>/cart.php" class="cart-btn">
                        <i class="bi bi-bag fs-5"></i>
                        <?php if($cartCount > 0): ?><span class="cart-badge"><?= $cartCount ?></span><?php endif; ?>
                    </a>
                    <div class="cart-preview d-none d-lg-block">
                        <div style="padding:16px 18px; border-bottom:1px solid #f1f5f9; display:flex; justify-content:space-between;">
                            <strong style="font-family:'Plus Jakarta Sans'; font-size:15px;">Bag (<?= $cartCount ?>)</strong>
                            <a href="<?= $siteBase ?>/cart.php" style="font-size:13px; color:var(--primary); font-weight:600; text-decoration:none;">View all</a>
                        </div>
                        <?php if(empty($cart)): ?>
                            <div class="text-center py-4 px-3">
                                <div style="width:56px; height:56px; background:#f8fafc; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 12px; font-size:24px;">🛒</div>
                                <p class="mb-1 fw-semibold" style="font-size:14px;">Your bag is empty</p>
                                <a href="<?= $siteBase ?>/shop.php" class="btn btn-dark btn-sm rounded-pill px-3 mt-2">Start Shopping</a>
                            </div>
                        <?php else: ?>
                            <div style="max-height:260px; overflow-y:auto;">
                                <?php foreach(array_slice($cart, 0, 3) as $item): ?>
                                    <div class="cart-item">
                                        <img src="<?= $item['image'] ?: 'https://via.placeholder.com/48' ?>" alt="">
                                        <div class="flex-grow-1">
                                            <div style="font-size:13px; font-weight:600; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:180px;"><?= htmlspecialchars($item['name']) ?></div>
                                            <div style="font-size:12px; color:#64748b;">Qty: <?= $item['quantity'] ?></div>
                                        </div>
                                        <div style="font-size:13px; font-weight:700;">Rs.<?= number_format($item['price']*$item['quantity']) ?></div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <div style="padding:14px 18px; background:#f8fafc; border-radius:0 0 20px 20px;">
                                <div class="d-flex justify-content-between mb-3">
                                    <span style="font-size:13px; color:#64748b;">Subtotal</span>
                                    <strong>Rs.<?= number_format($cartTotal,2) ?></strong>
                                </div>
                                <a href="<?= $siteBase ?>/checkout.php" class="btn w-100 text-white fw-semibold" style="background:var(--dark); border-radius:12px; padding:10px;">Checkout</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if(isLoggedIn()): ?>
                    <div class="position-relative user-menu-wrap">
                        <div class="user-trigger">
                            <span class="d-none d-md-inline" style="font-size:13px; font-weight:600; max-width:100px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;"><?= htmlspecialchars(explode(' ', $_SESSION['user_name'])[0]) ?></span>
                            <div class="avatar"><?= strtoupper(substr($_SESSION['user_name'],0,1)) ?></div>
                        </div>
                        <div class="user-dropdown">
                            <div style="padding:10px 12px 12px; border-bottom:1px solid #f1f5f9; margin-bottom:6px;">
                                <div style="font-weight:700; font-size:14px;"><?= htmlspecialchars($_SESSION['user_name']) ?></div>
                                <div style="font-size:12px; color:#64748b;"><?= htmlspecialchars($_SESSION['email'] ?? '') ?></div>
                            </div>
                            <a href="<?= $siteBase ?>/account.php" class="dropdown-item-premium"><i class="bi bi-person"></i> My Account</a>
                            <?php if(isAdmin()): ?>
                                <a href="<?= $siteBase ?>/admin/index.php" class="dropdown-item-premium" style="background:#0f172a; color:white;"><i class="bi bi-speedometer2"></i> Admin</a>
                            <?php endif; ?>
                            <a href="<?= $siteBase ?>/logout.php" class="dropdown-item-premium" style="color:#dc2626;"><i class="bi bi-box-arrow-right"></i> Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="<?= $siteBase ?>/login.php" class="nav-link-premium d-none d-md-inline-flex text-decoration-none">Login</a>
                    <a href="<?= $siteBase ?>/register.php" class="btn-register text-decoration-none">Register</a>
                <?php endif; ?>
            </div>

            <form action="<?= $siteBase ?>/shop.php" method="GET" class="d-lg-none mt-3 position-relative">
                <i class="bi bi-search position-absolute" style="left:14px; top:50%; transform:translateY(-50%); color:#94a3b8;"></i>
                <input type="text" name="search" class="form-control ps-5" style="background:#f8fafc; border-radius:100px;" placeholder="Search products...">
            </form>
        </div>
    </div>
</nav>

<script>
    window.addEventListener('scroll', () => {
        document.getElementById('mainNav').classList.toggle('scrolled', window.scrollY > 20);
    });
</script>

<main class="min-vh-100" style="background:#f8fafc;">