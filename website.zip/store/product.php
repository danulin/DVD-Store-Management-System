<?php
require_once 'config/config.php';
if(!isset($_GET['id'])){ header("Location: shop.php"); exit; }
$id = (int)$_GET['id'];
$stmt = $db->prepare("SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.id=:id");
$stmt->execute([':id'=>$id]);
$product = $stmt->fetch();
if(!$product){ header("Location: shop.php"); exit; }

if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['add_to_cart'])){
    $qty = max(1, (int)$_POST['quantity']);
    if(!isset($_SESSION['cart'])) $_SESSION['cart']=[];
    if(isset($_SESSION['cart'][$id])){
        $_SESSION['cart'][$id]['quantity'] += $qty;
    } else {
        $_SESSION['cart'][$id] = [
            'id'=>$product['id'],
            'name'=>$product['name'],
            'price'=>$product['price'],
            'image'=>$product['image_url'],
            'quantity'=>$qty
        ];
    }
    header("Location: cart.php?added=1");
    exit;
}
$pageTitle = $product['name'];
include 'includes/header.php';
$finalImg = (strpos($product['image_url'], 'assets/')===0) ? BASE_URL . '/' . $product['image_url'] : $product['image_url'];
if(strpos($finalImg, 'unsplash.com')!==false){ $finalImg = BASE_URL . '/assets/images/products/product_001_iphone-15-pro-max-256gb_techmart.jpg'; }
?>
<div class="container py-5">
  <nav aria-label="breadcrumb"><ol class="breadcrumb" style="font-size:13px;"><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/index.php" class="text-decoration-none">Home</a></li><li class="breadcrumb-item"><a href="<?= BASE_URL ?>/shop.php" class="text-decoration-none">Shop</a></li><li class="breadcrumb-item active"><?= htmlspecialchars($product['name']) ?></li></ol></nav>
  <div class="row g-5 mt-1">
    <div class="col-lg-6">
      <div style="background:white; border:1px solid #f1f5f9; border-radius:20px; padding:20px;"><img src="<?= $finalImg ?>" class="img-fluid rounded" style="width:100%; height:440px; object-fit:contain; background:#f8fafc; border-radius:12px;" alt="<?= htmlspecialchars($product['name']) ?>" onerror="this.src='<?= BASE_URL ?>/assets/images/products/product_001_iphone-15-pro-max-256gb_techmart.jpg'"></div>
    </div>
    <div class="col-lg-6">
      <small class="text-uppercase fw-bold" style="letter-spacing:0.08em; color:#6366f1; font-size:11px;"><?= htmlspecialchars($product['cat_name']) ?></small>
      <h1 class="fw-bold mt-2" style="font-family:'Plus Jakarta Sans'; font-size:32px; line-height:1.1;"><?= htmlspecialchars($product['name']) ?></h1>
      <div class="d-flex align-items-center gap-2 mt-3">
        <h3 class="fw-bold mb-0" style="font-family:'Plus Jakarta Sans';">Rs.<?= number_format($product['price'],0) ?></h3>
        <?php if($product['stock_quantity']>0): ?><span class="badge" style="background:#dcfce7; color:#166534; border-radius:100px; padding:6px 12px;">In Stock - <?= $product['stock_quantity'] ?> left</span><?php else: ?><span class="badge bg-danger" style="border-radius:100px;">Out of Stock</span><?php endif; ?>
      </div>
      <p class="mt-4 text-muted" style="line-height:1.6;"><?= nl2br(htmlspecialchars($product['description'])) ?></p>
      <form method="POST" class="mt-4">
        <div class="d-flex gap-3 align-items-center">
          <input type="number" name="quantity" value="1" min="1" max="<?= $product['stock_quantity'] ?>" class="form-control" style="width:90px; border-radius:12px; padding:12px; text-align:center; font-weight:700;">
          <button name="add_to_cart" class="btn btn-dark flex-fill" style="border-radius:12px; padding:12px 24px; font-weight:600;"><i class="bi bi-bag-plus me-2"></i>Add to Cart</button>
        </div>
      </form>
      <div class="mt-4 p-3" style="background:#f8fafc; border:1px solid #f1f5f9; border-radius:14px;">
        <div class="d-flex gap-3 small"><div><i class="bi bi-truck me-1"></i> Free delivery over Rs.5000</div><div><i class="bi bi-shield-check me-1"></i> 1 year warranty</div></div>
      </div>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
