<?php
require_once 'config/config.php';
$pageTitle = "Shopping Cart";
include 'includes/header.php';

if(isset($_GET['remove'])){
    $rid = (int)$_GET['remove'];
    unset($_SESSION['cart'][$rid]);
    header("Location: cart.php");
    exit;
}
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['update_cart'])){
    foreach($_POST['qty'] as $pid=>$qty){
        $pid=(int)$pid; $qty=(int)$qty;
        if($qty<=0) unset($_SESSION['cart'][$pid]);
        else $_SESSION['cart'][$pid]['quantity']=$qty;
    }
    header("Location: cart.php?updated=1");
    exit;
}
$cart = $_SESSION['cart'] ?? [];
$total = 0;
foreach($cart as $item){ $total += $item['price'] * $item['quantity']; }
?>
<div class="container py-5">
  <h3 class="fw-bold mb-4">Shopping Cart (<?= getCartCount() ?> items)</h3>
  <?php if(isset($_GET['added'])): ?><div class="alert alert-success">Product added to cart!</div><?php endif; ?>
  <?php if(isset($_GET['updated'])): ?><div class="alert alert-info">Cart updated!</div><?php endif; ?>
  <?php if(empty($cart)): ?>
    <div class="text-center py-5"><i class="bi bi-cart-x fs-1 text-muted"></i><p class="mt-3">Your cart is empty</p><a href="shop.php" class="btn btn-primary">Continue Shopping</a></div>
  <?php else: ?>
  <form method="POST">
  <div class="row">
    <div class="col-md-8">
      <div class="card shadow-sm">
        <div class="card-body">
          <table class="table align-middle">
            <thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Subtotal</th><th></th></tr></thead>
            <tbody>
            <?php foreach($cart as $item): ?>
              <tr>
                <td><div class="d-flex align-items-center gap-2"><img src="<?= $item['image'] ?: '<?= BASE_URL ?>/assets/images/products/product_001_iphone-15-pro-max-256gb_techmart.jpg' ?>" width="50" height="50" style="object-fit:cover" class="rounded"><span><?= sanitize($item['name']) ?></span></div></td>
                <td><?= formatPrice($item['price']) ?></td>
                <td><input type="number" name="qty[<?= $item['id'] ?>]" value="<?= $item['quantity'] ?>" min="1" class="form-control form-control-sm qty-input" style="width:70px"></td>
                <td><?= formatPrice($item['price']*$item['quantity']) ?></td>
                <td><a href="cart.php?remove=<?= $item['id'] ?>" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></a></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
          <div class="d-flex justify-content-between">
            <a href="shop.php" class="btn btn-outline-secondary">Continue Shopping</a>
            <button type="submit" name="update_cart" class="btn btn-outline-primary">Update Cart</button>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5>Order Summary</h5>
          <div class="d-flex justify-content-between mt-3"><span>Subtotal</span><span><?= formatPrice($total) ?></span></div>
          <div class="d-flex justify-content-between"><span>Shipping</span><span class="text-success">Free</span></div>
          <hr>
          <div class="d-flex justify-content-between fw-bold fs-5"><span>Total</span><span><?= formatPrice($total) ?></span></div>
          <a href="checkout.php" class="btn btn-primary w-100 mt-3 btn-lg">Proceed to Checkout</a>
        </div>
      </div>
    </div>
  </div>
  </form>
  <?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>
