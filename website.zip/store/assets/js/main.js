
document.addEventListener('DOMContentLoaded', ()=>{
  const qtyInputs = document.querySelectorAll('.qty-input');
  qtyInputs.forEach(i=>{
    i.addEventListener('change', function(){
      if(this.value < 1) this.value = 1;
    });
  });
});
