<?php
require_once 'config/config.php';
requireLogin();
$pageTitle="My Account";
include 'includes/header.php';

$stmt = $db->prepare("SELECT * FROM orders WHERE user_id=:uid ORDER BY created_at DESC");
$stmt->execute([':uid'=>$_SESSION['user_id']]);
$orders = $stmt->fetchAll();

$userStmt = $db->prepare("SELECT * FROM users WHERE id=:id");
$userStmt->execute([':id'=>$_SESSION['user_id']]);
$user = $userStmt->fetch();
?>
<div class="container py-5">
  <h3 class="fw-bold">My Account</h3>
  <div class="row mt-4">
    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-body text-center">
          <i class="bi bi-person-circle fs-1"></i>
          <h5 class="mt-2"><?= sanitize($user['name']) ?></h5>
          <p class="text-muted small"><?= sanitize($user['email']) ?></p>
          <p><span class="badge bg-primary"><?= ucfirst($user['role']) ?></span></p>
          <hr>
          <p class="small text-muted">Member since <?= date('M Y', strtotime($user['created_at'])) ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-8">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5>My Orders (<?= count($orders) ?>)</h5>
          <?php if(empty($orders)): ?>
            <p class="text-muted">No orders yet. <a href="shop.php">Start shopping</a></p>
          <?php else: ?>
          <div class="table-responsive">
            <table class="table">
              <thead><tr><th>Order ID</th><th>Total</th><th>Status</th><th>Date</th><th>Action</th></tr></thead>
              <tbody>
              <?php foreach($orders as $o): ?>
                <tr>
                  <td>#<?= $o['id'] ?></td>
                  <td><?= formatPrice($o['total_amount']) ?></td>
                  <td><span class="badge bg-<?= $o['status']=='pending'?'warning':($o['status']=='completed'?'success':'secondary') ?>"><?= ucfirst($o['status']) ?></span></td>
                  <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
                  <td><button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#orderModal<?= $o['id'] ?>">View</button></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php foreach($orders as $o):
  $itemsStmt = $db->prepare("SELECT oi.*, p.name FROM order_items oi JOIN products p ON oi.product_id=p.id WHERE oi.order_id=:oid");
  $itemsStmt->execute([':oid'=>$o['id']]);
  $items = $itemsStmt->fetchAll();
?>
<div class="modal fade" id="orderModal<?= $o['id'] ?>" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><h5>Order #<?= $o['id'] ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body">
  <p><strong>Shipping:</strong> <?= sanitize($o['shipping_name']) ?>, <?= sanitize($o['shipping_address']) ?>, <?= sanitize($o['shipping_phone']) ?></p>
  <table class="table small"><thead><tr><th>Product</th><th>Qty</th><th>Price</th></tr></thead><tbody>
  <?php foreach($items as $it): ?><tr><td><?= sanitize($it['name']) ?></td><td><?= $it['quantity'] ?></td><td><?= formatPrice($it['price']) ?></td></tr><?php endforeach; ?>
  </tbody></table>
  <p class="fw-bold">Total: <?= formatPrice($o['total_amount']) ?></p>
</div></div></div></div>
<?php endforeach; ?>

<?php include 'includes/footer.php'; ?>
