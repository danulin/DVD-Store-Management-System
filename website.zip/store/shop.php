<?php
require_once 'config/config.php';
$pageTitle = "Shop";
include 'includes/header.php';

$categoryFilter = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'newest';

$sql = "SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.status='active'";
$params = [];

if($categoryFilter > 0){
  $sql .= " AND p.category_id = :cat";
  $params[':cat'] = $categoryFilter;
}
if($search !== ''){
  $sql .= " AND (p.name LIKE :search OR p.description LIKE :search)";
  $params[':search'] = "%$search%";
}

if($sort == 'price_low') $sql .= " ORDER BY p.price ASC";
elseif($sort == 'price_high') $sql .= " ORDER BY p.price DESC";
else $sql .= " ORDER BY p.created_at DESC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

$categories = $db->query("SELECT * FROM categories ORDER BY name")->fetchAll();
?>
<div class="container py-4">
  <div class="row">
    <div class="col-md-3">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5>Filters</h5>
          <form method="GET">
            <div class="mb-3">
              <label class="form-label">Search</label>
              <input type="text" name="search" class="form-control" value="<?= sanitize($search) ?>" placeholder="Search products">
            </div>
            <div class="mb-3">
              <label class="form-label">Category</label>
              <select name="category" class="form-select">
                <option value="0">All Categories</option>
                <?php foreach($categories as $cat): ?>
                <option value="<?= $cat['id'] ?>" <?= $categoryFilter==$cat['id']?'selected':'' ?>><?= sanitize($cat['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="mb-3">
              <label class="form-label">Sort By</label>
              <select name="sort" class="form-select">
                <option value="newest" <?= $sort=='newest'?'selected':'' ?>>Newest</option>
                <option value="price_low" <?= $sort=='price_low'?'selected':'' ?>>Price Low to High</option>
                <option value="price_high" <?= $sort=='price_high'?'selected':'' ?>>Price High to Low</option>
              </select>
            </div>
            <button class="btn btn-primary w-100">Apply</button>
            <a href="shop.php" class="btn btn-outline-secondary w-100 mt-2">Reset</a>
          </form>
        </div>
      </div>
    </div>
    <div class="col-md-9">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0"><?= count($products) ?> Products Found</h4>
      </div>
      <div class="row g-4">
        <?php if(empty($products)): ?>
          <div class="col-12 text-center py-5"><p class="text-muted">No products found.</p></div>
        <?php endif; ?>
        <?php foreach($products as $p): ?>
        <div class="col-md-4 col-sm-6">
          <div class="card product-card shadow-sm h-100">
            <img src="<?= $p['image_url'] ?: 'https://via.placeholder.com/300x200?text='.urlencode($p['name']) ?>" class="product-img card-img-top">
            <div class="card-body">
              <small class="text-muted"><?= sanitize($p['cat_name']) ?></small>
              <h6 class="card-title mt-1"><?= sanitize($p['name']) ?></h6>
              <span class="fw-bold text-primary"><?= formatPrice($p['price']) ?></span>
            </div>
            <div class="card-footer bg-white border-0 d-flex gap-2">
              <a href="product.php?id=<?= $p['id'] ?>" class="btn btn-outline-dark btn-sm w-50">View</a>
              <a href="product.php?id=<?= $p['id'] ?>" class="btn btn-primary btn-sm w-50">Add</a>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
