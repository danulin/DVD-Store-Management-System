<?php
require_once 'config/config.php';
$pageTitle = "About Us";
include 'includes/header.php';
?>
<style>
.about-hero { background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%); color:white; padding:80px 0; position:relative; overflow:hidden; }
.about-hero::before { content:''; position:absolute; width:600px; height:600px; background:radial-gradient(circle, rgba(99,102,241,0.25) 0%, transparent 70%); top:-200px; right:-100px; }
.about-card { background:white; border:1px solid #f1f5f9; border-radius:20px; padding:28px; text-align:center; transition:all 0.3s; height:100%; }
.about-card:hover { transform:translateY(-4px); box-shadow:0 20px 40px rgba(15,23,42,0.08); }
.about-icon { width:64px; height:64px; border-radius:16px; display:flex; align-items:center; justify-content:center; font-size:28px; margin:0 auto 16px; }
</style>

<section class="about-hero">
  <div class="container position-relative">
    <div class="row align-items-center">
      <div class="col-lg-6">
        <span class="badge" style="background:rgba(255,255,255,0.1); border:1px solid rgba(255,255,255,0.15); padding:8px 14px; border-radius:100px; font-size:12px; letter-spacing:0.06em;"><i class="bi bi-award me-1"></i> TRUSTED SINCE 2023</span>
        <h1 class="fw-bold mt-3" style="font-family:'Plus Jakarta Sans'; font-size:42px; letter-spacing:-0.02em; line-height:1.1;">We make technology<br>accessible for everyone</h1>
        <p class="mt-3" style="color:#cbd5e1; font-size:17px; line-height:1.6;">Sri Lanka's trusted online electronics store, committed to quality products, fair prices, and island-wide fast delivery.</p>
        <div class="d-flex gap-3 mt-4">
          <div><h3 class="fw-bold mb-0" style="font-family:'Plus Jakarta Sans';">1000+</h3><small style="color:#94a3b8;">Happy Customers</small></div>
          <div style="width:1px; background:rgba(255,255,255,0.1);"></div>
          <div><h3 class="fw-bold mb-0" style="font-family:'Plus Jakarta Sans';">500+</h3><small style="color:#94a3b8;">Products</small></div>
          <div style="width:1px; background:rgba(255,255,255,0.1);"></div>
          <div><h3 class="fw-bold mb-0" style="font-family:'Plus Jakarta Sans';">4.9★</h3><small style="color:#94a3b8;">Rating</small></div>
        </div>
      </div>
      <div class="col-lg-6 mt-4 mt-lg-0">
        <div class="position-relative" style="background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.08); border-radius:24px; padding:24px; backdrop-filter:blur(20px);">
          <div class="d-flex align-items-center gap-3 mb-4">
            <img src="<?= BASE_URL ?>/assets/images/logo.png" alt="TechMart" style="height:40px; filter:brightness(0) invert(1);">
            <span style="font-weight:700;">TechMart.lk</span>
          </div>
          <div class="row g-3">
            <div class="col-6"><div style="background:white; border-radius:16px; padding:16px; text-align:center;"><i class="bi bi-truck fs-3 text-primary"></i><div class="fw-bold mt-2 small">Fast Delivery</div><small class="text-muted" style="font-size:11px;">Island-wide in 2-3 days</small></div></div>
            <div class="col-6"><div style="background:white; border-radius:16px; padding:16px; text-align:center;"><i class="bi bi-shield-check fs-3 text-success"></i><div class="fw-bold mt-2 small">1 Year Warranty</div><small class="text-muted" style="font-size:11px;">On all products</small></div></div>
            <div class="col-6"><div style="background:white; border-radius:16px; padding:16px; text-align:center;"><i class="bi bi-headset fs-3 text-info"></i><div class="fw-bold mt-2 small">24/7 Support</div><small class="text-muted" style="font-size:11px;">Chat & Hotline</small></div></div>
            <div class="col-6"><div style="background:white; border-radius:16px; padding:16px; text-align:center;"><i class="bi bi-arrow-repeat fs-3 text-warning"></i><div class="fw-bold mt-2 small">Easy Returns</div><small class="text-muted" style="font-size:11px;">7 days return</small></div></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<div class="container py-5">
  <div class="row g-4 mt-2">
    <div class="col-md-4"><div class="about-card"><div class="about-icon" style="background:#eef2ff; color:#6366f1;"><i class="bi bi-bullseye"></i></div><h5 style="font-family:'Plus Jakarta Sans'; font-weight:700;">Our Vision</h5><p class="text-muted small mb-0">To be Sri Lanka's leading e-commerce platform for electronics, trusted by every household.</p></div></div>
    <div class="col-md-4"><div class="about-card"><div class="about-icon" style="background:#ecfdf5; color:#10b981;"><i class="bi bi-heart"></i></div><h5 style="font-family:'Plus Jakarta Sans'; font-weight:700;">Our Values</h5><p class="text-muted small mb-0">Customer first, integrity, innovation, and quality — we deliver what we promise.</p></div></div>
    <div class="col-md-4"><div class="about-card"><div class="about-icon" style="background:#fffbeb; color:#f59e0b;"><i class="bi bi-lightning"></i></div><h5 style="font-family:'Plus Jakarta Sans'; font-weight:700;">Our Mission</h5><p class="text-muted small mb-0">Best shopping experience with fast delivery, secure payments, and excellent support.</p></div></div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
